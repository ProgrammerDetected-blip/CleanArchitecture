﻿using Microsoft.EntityFrameworkCore;
using CleanArchitecture.Core.Entities;

namespace CleanArchitecture.Infrastructure.Data
{
    public class AppDbContext(DbContextOptions<AppDbContext> dbContextOptions) : DbContext(dbContextOptions)
    {
        public DbSet<EmployeeEntity> employeeEntities { get; set; }

    }
}
