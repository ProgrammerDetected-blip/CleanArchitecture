﻿using CleanArchitecture.Core.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanArchitecture.Application.Services
{
    public interface IEmployeeService
    {
        Task<IEnumerable<EmployeeEntity>> GetEmployees();
        Task<EmployeeEntity> GetEmployeesByIDAsync(Guid id);
        Task<EmployeeEntity> AddEmployeesAsync(EmployeeEntity employeeEntity);
        Task<EmployeeEntity> UpdateEmployeesAsync(Guid employeeid, EmployeeEntity employeeEntity);
        Task<bool> DeleteEmployeesAsync(Guid employeeid, EmployeeEntity employeeEntity);
    }
}
