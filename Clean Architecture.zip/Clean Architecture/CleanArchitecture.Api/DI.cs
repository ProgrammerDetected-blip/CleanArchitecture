﻿using CleanArchitecture.Application;
using CleanArchitecture.Core;
using CleanArchitecture.Infrastructure;

namespace CleanArchitecture.Api
{
    public static class DI
    {
        public static IServiceCollection AddCleanArchitectureAppDI(this IServiceCollection services)
        {
            services.AddApplicationDI().AddInfrastructureDI();
            
            return services;
        }
    }
}
