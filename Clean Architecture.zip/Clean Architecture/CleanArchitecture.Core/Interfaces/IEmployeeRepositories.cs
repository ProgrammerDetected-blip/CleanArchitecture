﻿using CleanArchitecture.Core.Entities;


namespace CleanArchitecture.Core.Interfaces
{
    public interface IEmployeeRepositories
    {
        Task<IEnumerable<EmployeeEntity>> GetEmployees();
        Task<EmployeeEntity> GetEmployeesByIDAsync(Guid id);
        Task<EmployeeEntity> AddEmployeesAsync(EmployeeEntity employeeEntity);
        Task<EmployeeEntity> UpdateEmployeesAsync(Guid employeeid, EmployeeEntity employeeEntity);
        Task<bool> DeleteEmployeesAsync(Guid employeeid, EmployeeEntity employeeEntity);
    }
}
