﻿using CleanArchitecture.Core.Entities;
using CleanArchitecture.Core.Interfaces;
using CleanArchitecture.Infrastructure.Data;
using Microsoft.EntityFrameworkCore;


namespace CleanArchitecture.Infrastructure.Repositories
{
    public class EmployeeRepository(AppDbContext appDbContext) : IEmployeeRepositories
    {
        //“Fetch all rows from that table and put them into a list — do it asynchronously.”
        //async → this method works asynchronously (it won’t block the program while waiting).

        //Task<IEnumerable<EmployeeEntity>> → this method will return a task that eventually gives back a list of employees.

        //IEnumerable<EmployeeEntity> = “a collection of EmployeeEntity objects.”
        public async Task<IEnumerable<EmployeeEntity>> GetEmployees()
        {
            return await appDbContext.employeeEntities.ToListAsync();
        }
        public async Task<EmployeeEntity> GetEmployeesByIDAsync(Guid id)
        {
            return await appDbContext.employeeEntities.FirstOrDefaultAsync(x=> x.Id == id);
        }

        public async Task<EmployeeEntity> AddEmployeesAsync(EmployeeEntity employeeEntity)
        {
            employeeEntity.Id = Guid.NewGuid();
            appDbContext.employeeEntities.Add(employeeEntity);
           await appDbContext.SaveChangesAsync();
            return employeeEntity;
        }

        public async Task<EmployeeEntity> UpdateEmployeesAsync(Guid employeeid, EmployeeEntity employeeEntity)
        {
            var emp = await appDbContext.employeeEntities.FirstOrDefaultAsync(x => x.Id == employeeid);
            if (emp is not null) 
            {
                emp.EmployeeName = employeeEntity.EmployeeName;
                emp.PhoneNumber = employeeEntity.PhoneNumber;
                emp.Address = employeeEntity.Address;
                emp.Email   = employeeEntity.Email;
                emp.Designation=    employeeEntity.Designation;
                emp.JoiningDate = employeeEntity.JoiningDate;
                await appDbContext.SaveChangesAsync();
                return emp;
            }
            return employeeEntity;
        }
        public async Task<bool> DeleteEmployeesAsync(Guid employeeid, EmployeeEntity employeeEntity)
        {
            var emp = await appDbContext.employeeEntities.FirstOrDefaultAsync(x => x.Id == employeeid);
            if (emp is not null)
            {
                 appDbContext.employeeEntities.Remove(emp);
              return  await appDbContext.SaveChangesAsync()>0;
            }
            return false;
        }
    }
}
