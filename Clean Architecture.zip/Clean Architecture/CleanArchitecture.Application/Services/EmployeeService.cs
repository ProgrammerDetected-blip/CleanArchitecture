﻿using CleanArchitecture.Core.Entities;
using CleanArchitecture.Core.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CleanArchitecture.Application.Services
{
    public class EmployeeService : IEmployeeService
    {
        private readonly IEmployeeRepositories _repository;
        public EmployeeService(IEmployeeRepositories repository)
        {
            _repository = repository;
        }
        public async Task<IEnumerable<EmployeeEntity>> GetEmployees()
        {
            return await _repository.GetEmployees();
        }

        public async Task<EmployeeEntity> GetEmployeesByIDAsync(Guid id)
        {
            return await _repository.GetEmployeesByIDAsync(id);
        }

        public async Task<EmployeeEntity> AddEmployeesAsync(EmployeeEntity employeeEntity)
        {
            return await _repository.AddEmployeesAsync(employeeEntity);
        }

        public async Task<EmployeeEntity> UpdateEmployeesAsync(Guid employeeid, EmployeeEntity employeeEntity)
        {
            return await _repository.UpdateEmployeesAsync(employeeid, employeeEntity);
        }

        public async Task<bool> DeleteEmployeesAsync(Guid employeeid, EmployeeEntity employeeEntity)
        {
            return await _repository.DeleteEmployeesAsync(employeeid, employeeEntity);
        }
    }
}

